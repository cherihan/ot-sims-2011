from functools import wraps
from flask import g, request, redirect, abort, url_for

def logged_in_or(func, *args, **kwargs):
  def closure(f):
    @wraps(f)
    def decorated_function(*args2, **kwargs2):
      if g.user is None:
        return func(*args, **kwargs)
      else:
        return f(*args2, **kwargs2)
    return decorated_function
  return closure
  
def not_logged_in_or(func, *args, **kwargs):
  def closure(f):
    @wraps(f)
    def decorated_function(*args2, **kwargs2):
      if g.user is None:
        return f(*args2, **kwargs2)
      else:
        return func(*args, **kwargs)
    return decorated_function
  return closure
