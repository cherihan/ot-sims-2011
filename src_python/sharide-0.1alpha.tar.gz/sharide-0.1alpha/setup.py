from setuptools import setup, find_packages

setup(
    name='sharide',
    version='0.1alpha',
    long_description=__doc__,
    packages=['sharide'],
    include_package_data=True,
    zip_safe=False,
    install_requires=['Flask', 'Flask-SQLAlchemy', 'MySQL-python']
)
