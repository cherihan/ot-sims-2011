from flask import Flask
app = Flask(__name__)

import sharide.views
from models import db
