from __future__ import division
from . import app
from flaskext.sqlalchemy import SQLAlchemy
from sqlalchemy.ext.associationproxy import association_proxy
from werkzeug import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from time import time, mktime

db = SQLAlchemy(app)

class User(db.Model):
  id = db.Column(db.Integer, primary_key=True)
  email = db.Column(db.String(50), unique=True, nullable=False)
  password = db.Column(db.String(120), nullable=False)
  created_rides = db.relationship('Ride', backref='creator')
  passenger_in = association_proxy('UserRide', 'Ride')
  
  user_rides = db.relationship('UserRide', backref='user')

  def __repr__(self):
    return '<User %r - %r>' % (self.id, self.email)

class Ride(db.Model):
  
  __tablename__ = 'ride'
  
  def _create_passenger(user):
    return UserRide(user=user)
  
  id = db.Column(db.Integer, primary_key=True)
  creator_id = db.Column(db.Integer, db.ForeignKey(User.id), nullable=False)
  start = db.Column(db.String(120), nullable=False)
  end = db.Column(db.String(120), nullable=False)
  latitude = db.Column(db.Float, default=0, nullable=False) # FIXME: default value
  longitude = db.Column(db.Float, default=0, nullable=False) # FIXME: default value
  datetime = db.Column(db.DateTime(), nullable=False)
  type = db.Column(db.Enum('none', 'car', name='vehicle'), nullable=False)
  seats = db.Column(db.Integer, default=0, nullable=False)
  
  user_rides = db.relationship('UserRide', backref='ride')

  passengers = association_proxy('user_rides', 'User',
                                 creator=_create_passenger)

  __mapper_args__ = {'polymorphic_on': type}

  @property
  def pending_passengers(self):
    return User.query.join(User.user_rides, UserRide.ride) \
      .filter(Ride.id == self.id) \
      .filter(UserRide.status == 'pending')

  @property
  def seats_left(self):
    return self.seats - len(self.passengers)
  
  def init(self, *args, **kwrags):
    super(Ride, self).__init__(*args, **kwargs)
    self.query.pending_passengers = self.pending_passengers

  def __repr__(self):
    return '<Ride %r - %r -> %r>' % (self.id, self.start, self.end)
  
  @property
  def minutes_from_now(self):
    return int(round((mktime(self.datetime.timetuple()) - time())/60))

class RideNeeded(Ride):
  __tablename__ = None # flaskext.sqlalchemy's bug workaround
  __mapper_args__ = {'polymorphic_identity': 'none'}

class CarRide(Ride):
  __tablename__ = None # flaskext.sqlalchemy's bug workaround
  __mapper_args__ = {'polymorphic_identity': 'car'}

class UserRide(db.Model):
  
  user_id = db.Column(db.Integer, db.ForeignKey(User.id), nullable=False,
                                                    primary_key=True)
  ride_id = db.Column(db.Integer, db.ForeignKey(Ride.id), nullable=False,
                                                    primary_key=True)
  status = db.Column(db.Enum(u'pending', u'approved', name='status'),
                  default=u'pending',
                  nullable=False)
  
  def is_pending(self): return self.status == 'pending'
  def is_approved(self): return self.status == 'approved'
  
  def approve(self):
    self.status = 'approved'

