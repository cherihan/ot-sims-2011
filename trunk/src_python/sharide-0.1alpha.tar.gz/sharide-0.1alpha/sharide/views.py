# coding: utf-8

from flask import render_template, g, session, redirect, url_for, request,\
                  flash, abort
from . import app
from decorators import logged_in_or, not_logged_in_or
from models import db, User, Ride, CarRide, RideNeeded
from datetime import datetime, timedelta


def auto_redirect(endpoint):
  return redirect(url_for(endpoint))

def redirect_with_flash(endpoint, msg, category):
  flash(msg, category)
  return auto_redirect(endpoint)

@app.before_request
def before_request():
  g.user = User.query.filter_by(id=session.get('user_id')).first()

##
## Application index
##

@app.route('/')
def index():
  if g.user is None:
    return render_template('landing.html')
  else:
    return render_template('home.html')

##
## Rides management
##

@app.route('/rides/')
@logged_in_or(redirect_with_flash, 'login', 'Vous devez vous connecter', 'info')
def rides_index():
  rides = g.user.created_rides
  rides.sort(lambda x, y: cmp(x.datetime, y.datetime), reverse=True)
  return render_template('rides/index.html', rides=rides)

@app.route('/rides/<int:ride_id>')
def show_ride(ride_id):
  return 'qwerty'

@app.route('/rides/create', methods=['GET', 'POST'])
@logged_in_or(redirect_with_flash, 'login', 'Vous devez vous connecter', 'info')
def create_ride():
  type = request.values['type']
  if request.method == 'POST':
    minutes = int(request.form['time'])
    if type == 'none':
      cls = RideNeeded
    else:
      cls = CarRide
    ride = cls(
      creator = g.user,
      start = request.form['start'],
      end = request.form['end'],
      datetime = datetime.today() + timedelta(0,0,0,0,minutes),
      seats = request.form.get('seats', 0),
    )
    db.session.add(ride)
    try:
      db.session.commit()
    except Exception, e:
      app.logger.debug('An error occurred with the DB: %s' % e)
      flash(u'Erreurs dans le formulaire', 'error')
      db.session.rollback()
    else:
      flash(u'Trajet créé :)', 'info')
      return redirect(url_for('index'))
  if type == 'none':
    return render_template('rides/create_without_vehicle.html')
  else:
    return render_template('rides/create_with_vehicle.html')

##
## User management
##

@app.route('/users/<int:user_id>')
@logged_in_or(auto_redirect, 'index')
def show_user(user_id):
  user = User.query.filter_by(id=user_id).first_or_404()
  return render_template('users/show.html', user=user)

@app.route('/users/<int:user_id>/edit', methods=['GET', 'POST'])
@logged_in_or(abort, 403)
def edit_user(user_id):
  if g.user.id == user_id:
    if request.method == 'POST':
      g.user.email = request.form['email']
      db.session.commit()
      return redirect(url_for('show_user', user_id=user_id))
    return render_template('users/edit.html', user=g.user)
  else:
    abort(403)

@app.route('/users/<int:user_id>/edit_password', methods=['GET', 'POST'])
@logged_in_or(abort, 403)
def edit_user_password(user_id):
  if g.user.id == user_id:
    if request.method == 'POST':
      if request.form['password'] != request.form['password2']:
        flash(u'Vos mots de passe diffèrent', 'error')
        return redirect(url_for('edit_user_password', user_id=user_id))
      g.user.password = request.form['password']
      db.session.commit()
      return redirect(url_for('edit_user', user_id=user_id))
    return render_template('users/edit_password.html', user=g.user)
  else:
    abort(403)

@app.route('/users/create', methods=['GET', 'POST'])
@not_logged_in_or(auto_redirect, 'index')
def create_user():
  if request.method == 'POST':
    if request.form['password'] != request.form['password2']:
      flash(u'Vos mots de passe diffèrent', 'error')
    else:
      user = User(email=request.form['email'], password=request.form['password'])
      db.session.add(user)
      try:
        db.session.commit()
      except Exception, e:
        app.logger.debug('An error occurred with the DB: %s' % e)
        flash(u'Erreurs dans le formulaire', 'error')
        db.session.rollback()
      else:
        session['user_id'] = user.id
        flash(u'Compte créé. Vous êtes connecté', 'info')
        return redirect(url_for('index'))
  return render_template('users/create.html')

##
## Authentication management
##

@app.route('/login', methods=['GET', 'POST'])
@not_logged_in_or(auto_redirect, 'index')
def login():
  if request.method == 'POST':
    res = User.query.filter_by(email=request.form['email'],
                               password=request.form['password'])
    user = res.first()
    if user is None:
      flash(u'Erreur d’identification', 'error')
      return redirect(url_for('login'))
    session['user_id'] = user.id
    flash(u'Connecté', 'info')
    return redirect(url_for('index'))
  return render_template('login.html')

@app.route('/logout', methods=['GET', 'POST'])
@logged_in_or(auto_redirect, 'index')
def logout():
  del session['user_id']
  flash(u'Déconnecté !', 'info')
  return redirect(url_for('index'))
